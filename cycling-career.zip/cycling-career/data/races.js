window.CYCLING_RACES = [
  { id:'tour-down-under', name:'Tour Down Under', date:'2026-01-20', type:'Stage race', tier:'WorldTour', days:6 },
  { id:'paris-nice', name:'Paris-Nice', date:'2026-03-08', type:'Stage race', tier:'WorldTour', days:8 },
  { id:'tirreno', name:'Tirreno-Adriatico', date:'2026-03-09', type:'Stage race', tier:'WorldTour', days:7 },
  { id:'milan-sanremo', name:'Milano-Sanremo', date:'2026-03-21', type:'Monument', tier:'WorldTour', days:1 },
  { id:'ronde', name:'Ronde van Vlaanderen', date:'2026-04-05', type:'Monument', tier:'WorldTour', days:1 },
  { id:'paris-roubaix', name:'Paris-Roubaix', date:'2026-04-12', type:'Monument', tier:'WorldTour', days:1 },
  { id:'liege', name:'Liège-Bastogne-Liège', date:'2026-04-26', type:'Monument', tier:'WorldTour', days:1 },
  { id:'giro', name:'Giro d’Italia', date:'2026-05-09', type:'Grand Tour', tier:'WorldTour', days:21 },
  { id:'dauphine', name:'Critérium du Dauphiné', date:'2026-06-07', type:'Stage race', tier:'WorldTour', days:8 },
  { id:'tour', name:'Tour de France', date:'2026-07-04', type:'Grand Tour', tier:'WorldTour', days:21 },
  { id:'san-sebastian', name:'Clásica San Sebastián', date:'2026-08-01', type:'Classic', tier:'WorldTour', days:1 },
  { id:'vuelta', name:'La Vuelta', date:'2026-08-22', type:'Grand Tour', tier:'WorldTour', days:21 },
  { id:'worlds', name:'World Championships', date:'2026-09-20', type:'Worlds', tier:'Worlds', days:1 },
  { id:'il-lombardia', name:'Il Lombardia', date:'2026-10-10', type:'Monument', tier:'WorldTour', days:1 }
];
